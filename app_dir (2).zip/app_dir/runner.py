import os
from app import app
#from flask_script import Manager, Shell

#manager = Manager(app)


if __name__ == '__main__':
    app.run()