with open('purchase.txt', 'a') as fail:
    fail.write('9')
with open('purchase.txt', 'r') as db:
    data = list(map(int, db.read().split()))
print(data)

