import requests   # i'll have to install it
import json
import random

def new_coefficient(response):
    k = random.random()
    return k

def new_price(response):
    nk = new_coefficient(response)
    get_it = response['data'][0]
    data = {"id": get_it['id'], 'new coef': nk}  # i get product_name from ..?
    requests.post(url, json=data)

while True:
    url = 'http://127.0.0.1:5000/api/server'
    response = requests.get(url)
    print(response)
    r = response.json()
    response = r['data']
    np = new_price(r)




