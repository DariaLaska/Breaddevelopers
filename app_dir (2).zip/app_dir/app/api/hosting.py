from flask import Flask, request, render_template, jsonify
from flask_restful import Resource
import sqlalchemy as db
from app.data.orm.products import Product
from app.data.orm import db_session

import os
import json
import time

# is it here?

# @app.route('/host' , methods=['GET', 'POST'])
# def index():
#     return render_template('for_server.html')

class Server(Resource):
    def get(self): #im not sure about all these...
        # if req['user'] == 'client':    #{'user': 'client', 'product_name': 'product'}
        #      price = select(Product.price).where(Product.product_name == req['product_name'])
        #      return jsonify({'product': req['product_name'], 'price': price})


        db_sess = db_session.create_session()

        all_results = db_sess.query(Product).all()
        for_sending = {"data": []}
        for i in all_results:
            minimum = i.minimum
            maximum = i.maximum
            count = i.count
            current_purchases = i.current_purchases
            for_sending["data"].append({'id': i.id, 'maximum': maximum, 'minimum': minimum, 'count': count, 'current_purchases': current_purchases})

        return jsonify(for_sending)  # would it work?



    def post(self):
        task_data = request.get_json() #{"id": id, 'price': price}
        if not task_data:
            return jsonify({'message': 'No data provided'})

        id = task_data.get("id")
        new_coef = task_data.get("new coef")
        if not id:
            return {'message': "Message isn't correct :("}, 400

        db_sess = db_session.create_session()

        product = db_sess.query(Product).filter(Product.id ==id).first()
        product.coefficient = new_coef

        db_sess.commit()



class Client(Resource):
    def get(self, id): #im not sure about all these...
        db_sess = db_session.create_session()
        product = db_sess.query(Product).filter(Product.id == id).first()
        price = product.current_price
        return jsonify({'id': id, 'price': price})



if __name__ == '__main__':
    app.run(debug=True)