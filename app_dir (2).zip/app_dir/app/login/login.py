from flask_login import LoginManager, UserMixin, login_user
from wtforms import StringField, SubmitField, TextAreaField, BooleanField, PasswordField, validators
from flask_wtf import FlaskForm
#from wtforms import Form
from app import app
import sqlalchemy as db
from app.data.orm import users

login_manager = LoginManager(app)

class LoginForm(FlaskForm):
    login = StringField("login", validators=[validators.DataRequired()])
    password = PasswordField("password", validators=[validators.DataRequired()])  #PasswordField("Password", validators=[validators.DataRequired()])
    remember = BooleanField("Remember Me")
    submit = SubmitField()

class RegistrationForm(FlaskForm):
    login = StringField("login", validators=[validators.DataRequired()])
    password = PasswordField("password", validators=[validators.DataRequired()])  #PasswordField("Password", validators=[validators.DataRequired()])
    confirm_password = PasswordField("confirm_password", validators=[validators.DataRequired(), validators.EqualTo('password')])
    #remember = BooleanField("Remember Me")
    submit = SubmitField("Зарегистрироваться")


@login_manager.user_loader
def load_user(id):
    return db.session.query(users).get(id)