from app import app
from flask import render_template, request, redirect, url_for, flash, make_response, session
from flask_login import login_required, login_user,current_user, logout_user
#from app.data.forms import ContactForm, LoginForm
from .data.orm.users import Users
from app.login.login import LoginForm, RegistrationForm
from app.data.orm.users import Users
from app.data.orm.futures import Futures
from app.data.orm.products import Product
#import sqlalchemy as db
from app.data.orm import db_session
from bs4 import BeautifulSoup
import requests

# @login_manager.user_loader
# def load_user(user_id):
#     return db.session.query(Users).get(user_id)



@app.route('/registration', methods=['GET', 'POST'])
def registration():
    db_sess = db_session.create_session()
    form = RegistrationForm()
    if form.validate_on_submit():
        user = db_sess.query(Users).filter(Users.login == form.login.data).first()
        if user:
            flash("Your account has already existed", 'error')
            return render_template('login.html', form=form)
        else:
            if form.password.data == form.confirm_password.data:
                user = Users(login=form.login.data)
                user.set_password(form.password.data)
                db_sess.add(user)
                db_sess.commit()
                flash('Congratulations, you are now a registered user!')
            else:
                flash("Invalid password", 'error')
                #return render_template('reg.html', form=form)

    return render_template('reg.html', form=form)


@app.route('/login', methods=['GET', 'POST'])    # or i need to divide it to get and post(like LoginForm is get, other strings are post) or i can use request(library) and whet it's only post
def login():
    db_sess = db_session.create_session()
    form = LoginForm()
    if form.validate_on_submit():
        user = db_sess.query(Users).filter(Users.login == form.login.data).first()
        if user:
                if user.check_password(form.password.data):
                    return redirect('/api/server')

                flash("Invalid password", 'error')
                return render_template('login.html', form=form)
        flash("You're not sign in")
        reg_form = RegistrationForm()
        return render_template('reg.html', form=reg_form)

    return render_template('login.html', form=form)


# @app.route('/balance/<id>', methods=['GET', 'POST'])
# def futures(id):
#     db_sess = db_session.create_session()
#     balance = db_sess.query(Users.balance).filter(Users.id  == id).first()
#     return render_template('briefcase.html', balance = balance)  #it looks like price and comma (2000,) and i dont understand why

@app.route('/futures/<id>', methods=['GET', 'POST'])
def futures(id):
    db_sess = db_session.create_session()
    future = db_sess.query(Futures).filter(Futures.id  == id).first()
    pr_name = db_sess.query(Product).filter(Product.id  == future.product_id).first()
    us_balance = db_sess.query(Users).filter(Users.id == id).first()
    #price = future.price
#     data = future.data
#     address = future.address
    return render_template('briefcase_menu.html',  balance = us_balance.balance, product_name = pr_name.name, price = future.price) #, data = future.data, address = future.address
