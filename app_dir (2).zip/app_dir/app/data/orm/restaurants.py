import sqlalchemy as db
from .db_session import SqlAlchemyBase
from flask_login import UserMixin
from sqlalchemy_serializer import SerializerMixin

class Restaurant(SqlAlchemyBase, UserMixin, SerializerMixin):
    __tablename__ = 'restaurant'
    id = db.Column(db.Integer(), primary_key=True, nullable=False)
    address = db.Column(db.String(), nullable=False)
    #product = db.relationship('Product', backref='restaurants')

    def __init__(self, id, address):
        self.id = id
        self.address = address
