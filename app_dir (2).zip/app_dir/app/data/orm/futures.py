# from flask_login import LoginManager, UserMixin, login_user
# from sqlalchemy.orm import relationship
# from app import db
import sqlalchemy as db
from .db_session import SqlAlchemyBase
from flask_login import UserMixin
from sqlalchemy_serializer import SerializerMixin

class Futures(SqlAlchemyBase, UserMixin, SerializerMixin):
    __tablename__ = 'futures'
    id = db.Column(db.Integer(), primary_key=True, nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'))
    price = db.Column(db.Numeric())
    provision_data = db.Column(db.String(), nullable=False)
    id_restaurant = db.Column(db.Integer, db.ForeignKey('restaurant.id')) #???
    id_user = db.Column(db.Integer, db.ForeignKey('users.id')) #???

    def __init__(self, id, price, provision_data, address):
        self.id = id
        self.price = price
        self.provision_data = provision_data
        self.address = address
