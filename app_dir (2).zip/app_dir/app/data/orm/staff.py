from flask_login import LoginManager, UserMixin, login_user
from sqlalchemy.orm import relationship
import sqlalchemy as db
from .db_session import SqlAlchemyBase
from flask_login import UserMixin
from sqlalchemy_serializer import SerializerMixin

class Staff(SqlAlchemyBase, UserMixin, SerializerMixin):
    __tablename__ = 'staff'
    id = db.Column(db.Integer(), primary_key=True, nullable=False)
    id_restaurant = db.Column(db.Integer, db.ForeignKey('restaurant.id')) #??? im not really sure, and it needed to check all parametres
    #Column(db.Integer(), ForeignKey('restaurant.id'))
    login = db.Column(db.String(), nullable=False, unique=True)
    password = db.Column(db.String())
    account_type = db.Column(db.String())

    def __init__(self, id, id_restaurant, login, password, account_type):
        self.id = id
        self.id_restaurant = id_restaurant
        self.login = login
        self.password = password
        self.account_type = account_type
