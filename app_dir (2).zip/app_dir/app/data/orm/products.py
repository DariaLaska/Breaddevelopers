# from flask_login import LoginManager, UserMixin, login_user
# import sqlalchemy as db
# from sqlalchemy.orm import relationship
# #from app import db
# import sqlalchemy.ext.declarative as dec
#
# class Products(dec.declarative_base(), UserMixin):
#     tablename = 'products'
#     id = db.Column(db.Integer(), primary_key=True, nullable=False)
#     name = db.Column(db.String(), nullable=False)
#     maximum = db.Column(db.Numeric())
#     minimum = db.Column(db.Numeric())
#     count = db.Column(db.Integer())
#     price_history = db.Column(db.String())
#     id_restaurant = db.Column(db.Integer, db.ForeignKey('restaurant.id'))  #???
#     current_price = db.Column(db.Numeric())
#     #current_
#
#     def __init__(self, id, price, provision_data, address):
#         self.id = id
#         self.price = price
#         self.provision_data = provision_data
#         self.address = address

import sqlalchemy
from sqlalchemy import orm
from .db_session import SqlAlchemyBase
from flask_login import UserMixin
from sqlalchemy_serializer import SerializerMixin


class Product(SqlAlchemyBase, UserMixin, SerializerMixin):
    __tablename__ = 'products'

    id = sqlalchemy.Column(sqlalchemy.Integer(), primary_key=True, nullable=False, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String(), nullable=False)
    maximum = sqlalchemy.Column(sqlalchemy.Numeric())
    minimum = sqlalchemy.Column(sqlalchemy.Numeric())
    count = sqlalchemy.Column(sqlalchemy.Integer())
    price_history = sqlalchemy.Column(sqlalchemy.String())
    id_restaurant = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey('restaurant.id'))  #???
    current_price =sqlalchemy.Column(sqlalchemy.Numeric())
    coefficient = sqlalchemy.Column(sqlalchemy.Integer())
    current_purchases = sqlalchemy.Column(sqlalchemy.Integer())