# from flask_login import LoginManager, UserMixin, login_user
from werkzeug.security import generate_password_hash, check_password_hash
# from app import db
import sqlalchemy as db
from .db_session import SqlAlchemyBase
from flask_login import UserMixin
from sqlalchemy_serializer import SerializerMixin

def load_user(id):
    return db.session.query(Users).get(id)


class Users(SqlAlchemyBase, UserMixin, SerializerMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer(), primary_key=True, nullable=False, autoincrement=True)
    login = db.Column(db.String(), nullable=False, unique=True)
    password = db.Column(db.String())
    balance = db.Column(db.Integer())

    def __init__(self, id, login, password, balance):
        self.id = id
        self.login = login
        self.password = password
        self.balance = balance

    def set_password(self, password):
        self.password = generate_password_hash(password)
        return self.password

    def check_password(self, password):
        return check_password_hash(self.password, password)