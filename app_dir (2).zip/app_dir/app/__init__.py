from flask import Flask
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_restful import Api
import os, config
from app.data.orm import db_session
from app.api.hosting import Server, Client

#from products import Product


# создание экземпляра приложения
app = Flask(__name__)
api = Api(app)
db_session.global_init("app/db/app_db.db") #"app/db/app_db.db""sqlite:///app_db.db"
app.config.from_object(os.environ.get('FLASK_ENV') or 'config.DevelopementConfig')
# инициализирует расширения
db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

api.add_resource(Server, '/api/server')
api.add_resource(Client, '/api/client/<id>')

# import views
from . import views
# from . import forum_views
# from . import admin_views