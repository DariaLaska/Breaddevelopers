var svg = d3.select("body").append("svg")
    .attr("width", "70%")
    .attr("height", 500)
    .append("g")
    .attr("transform", "translate(" + 50 +"," + 0 + ")")
    // .attr("top: 500px");

// Инициализируем начальные данные
var data = [480];
var t = 0;

// var y = d3.scaleLinear().range([500, 1]);
// var yAxis = d3.axisLeft(y);
// var valueline = d3.line()
//     .y(function (d) { return y(d.value); });
// function update(data) {
//     y.domain([0, d3.max(data, function (d) { return d.value; })]);
// }
// svg.append("g")
//     .attr("class", "axis")
//     .call(yAxis);

function generateData(num) {
    console.log(data[data.length - 1], num, 0)
    t = ((500 - num) - data[data.length - 1]) / 100
    console.log(t, 1)

    if (data.length > 100) {
        data.shift();
    }
}

// Определяем функцию для обновления графика
function update() {
    // Добавляем новую точку данных
    var t1 = (data[data.length - 1] + t)
    console.log(t1, 2)
    data.push(t1)
    // data.push(500)
    // Обновляем xScale++
    xScale.domain([0, data.length - 1]);

    // Обновляем линию
    svg.select("path")
        .attr("d", line(data))
        .attr("transform", null)
        .transition()
        .duration(0)
        .ease(d3.easeLinear)
        .attr("transform", "translate(" + xScale(-1) + ",0)") // Сдвигаем влево на один пиксель

    // Удаляем излишние данные
}

// Определяем xScale
var xScale = d3.scaleLinear()
    .domain([0, 100])
    .range([0, window.innerWidth]);

// Определяем line
var line = d3.line()
    .x(function (d, i) { return xScale(i); })
    .y(function (d) { return d; });



// Добавляем линию
svg.append("path")
    .datum(data)
    .attr("fill", "none")
    .attr("stroke", "steelblue")
    .attr("stroke-width", 2);

// Запускаем обновление каждую секунду
setInterval(update, 10);





// function update(data) {
//     svg.select(".y-axis")
//         .call(yAxis);
// }