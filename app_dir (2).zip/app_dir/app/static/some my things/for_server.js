////const userAction = async () => {
////  const response = await fetch('/tasks');
////  const myJson = await response.json(); //extract JSON from the http response
////  console.log(myJson);
////  alert(myJson);
////}
////import json
//
//let inputdata;
//function Input() {
////    $("#three_3").click(function () {
//    inputdata = document.getElementById('three_!').value;
////  });
//}
//
////const url = 'http://127.0.0.1:5000/example';
////const data = inputdata;
////
////fetch(
////    url,
////    {
////        method: "POST",
////        headers: { "Content-Type": "application/json" },
////        body: data,
////    }
////)
////.then(data => data.json())
////.then((json) => {
////    alert(JSON.stringify(json));
////});
//
//const userAction = async () => {
//  const response = await fetch('http://127.0.0.1:5000/example', {
//    method: 'POST',
//    body: inputdata, // string or object
//    headers: {
//      'Content-Type': 'application/json'
//    }
//  });
//  const myJson = await response.json(); //extract JSON from the http response
//  // do something with myJson
//  //mess = JSON.stringify(myJson);
//  console.log(myJson)
//}
//


//let inputdata;
//function Input() {
//    $("#three_3").click(function () {
//    inputdata = document.getElementById('three_!').value;
//});

$('#01').click(function(){
  var xhr = new XMLHttpRequest();
  var get_req = document.URL.split('/').slice(0, 3).join('/') + '/example';
  xhr.open('GET', get_req, false);
  xhr.send();
 if (xhr.status != 200) {
    console.log(xhr);
    return null
  } // обработка ошибки}
  var response = JSON.parse(xhr.responseText);
  console.log(response);

//  var xhr = new XMLHttpRequest();

  let inputdata = String(document.getElementById('three_!').value);
  xhr.open('POST', get_req);
  xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
  let message = JSON.stringify({
  'body': inputdata
  });
  xhr.send(message);

});

