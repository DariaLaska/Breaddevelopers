//const userAction = async () => {
//  const response = await fetch('/tasks');
//  const myJson = await response.json(); //extract JSON from the http response
//  console.log(myJson);
//}
//
//$(document).ready(function () {
// $("#one_1").click(function () {
//    let inputdata1 = document.getElementById('one_!').value;
//    //socket.emit('my_event', { data: inputData });
//  });
//
//  $("#two_2").click(function () {
//    let inputdata2 = document.getElementById('two_!').value;
//  });
//    $("#three_3").click(function () {
//    let inputdata3 = document.getElementById('three_!').value;
//  });
//    $("#four_4").click(function () {
//    let inputdata4 = document.getElementById('four_!').value;
//  });
//    $("#five_5").click(function () {
//    let inputdata5 = document.getElementById('five_!').value;
//  });
//}
//const url = 'http://http://127.0.0.1:5000/tasks'; //http://127.0.0.1:5000
//const data = {"futures": inputdata1, "product": inputdata2, "procent": inputdata3, "minimum": inputdata4, "maximum": inputdata5};
//
//
//fetch(
//    url,
//    {
//        method: "POST"
//        headers: { "Content-Type": "application/json" },
//        body: data,
//    }
//)
//.then(data => data.json())
//.then((json) => {
//    alert(JSON.stringify(json));
//});


//data
$(document).ready(function () {
 $("#one_1").click(function () {
    let inputdata1 = document.getElementById('one_!').value;
  });

  $("#two_2").click(function () {
    let inputdata2 = document.getElementById('two_!').value;
  });
    $("#three_3").click(function () {
    let inputdata3 = document.getElementById('three_!').value;
  });
    $("#four_4").click(function () {
    let inputdata4 = document.getElementById('four_!').value;
  });
    $("#five_5").click(function () {
    let inputdata5 = document.getElementById('five_!').value;
  });
})

//get
$('#one_1').click(function(){
  var xhr = new XMLHttpRequest();
  var get_req = document.URL.split('/').slice(0, 3).join('/') + '/task';
  xhr.open('GET', get_req, false);
  xhr.send();
 if (xhr.status != 200) {
    console.log(xhr);
    return null
  } // обработка ошибки}
  var response = JSON.parse(xhr.responseText);
  console.log(response);
 })

 //post
$('#one_1').click(function(){
  var xhr = new XMLHttpRequest();
  //let inputdata = String(document.getElementById('three_!').value);
  xhr.open('POST', get_req);
  xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
  let message = JSON.stringify({
  'field':'futures',
  'body': inputdata1
  });
  xhr.send(message);

});