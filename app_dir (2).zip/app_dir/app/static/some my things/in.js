// Установка параметров графика
var margin = {top: 20, right: 20, bottom: 30, left: 50},
    width = 600 - margin.left - margin.right,
    height = 300 - margin.top - margin.bottom;

// Создание холста
var svg = d3.select("body")
    .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
    .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

// Инициализация пустых данных
var data = [];
var time = 0;

// Создание шкалы для оси x
var x = d3.scaleLinear().range([0, width]);

// Создание шкалы для оси y
var y = d3.scaleLinear().range([height, 0]);

// Создание оси x и y
var xAxis = d3.axisBottom(x);
var yAxis = d3.axisLeft(y);

// Линия
var valueline = d3.line()
    .x(function(d) { return x(d.time); })
    .y(function(d) { return y(d.value); });

// Функция для генерации случайных данных
function generateData() {
  time++;
  return {time: time, value: Math.random() * 100};
}

// Функция для обновления графика с новыми данными
function update(data) {
  x.domain(d3.extent(data, function(d) { return d.time; }));
  y.domain([0, d3.max(data, function(d) { return d.value; })]);

  var path = svg.selectAll(".line")
    .data([data]);

  path.enter().append("path")
    .attr("class", "line")
    .merge(path)
    .transition()
    .duration(1000)
    .attr("d", valueline);

  path.exit().remove();

  svg.selectAll("g.axis").remove();

  // Добавление осей
  svg.append("g")
      .attr("class", "axis")
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis);

  svg.append("g")
      .attr("class", "axis")
      .call(yAxis);
}

// Инициализация графика с пустыми данными
update(data);

// Вызов функции для плавного обновления данных каждую секунду
setInterval(function() {
  data.push(generateData()); // Добавляем новые случайные данные
  if (data.length > 10) data.shift(); // Удаляем старые данные

  // Обновляем график с новыми данными
  update(data);
}, 1000);