var margin = { top: 20, right: 20, bottom: 30, left: 50 },
  width = 1000 - margin.left - margin.right,
  height = 300 - margin.top - margin.bottom;

// Создание холста
var svg = d3.select("body")
  .append("svg")
  .attr("width", width + margin.left + margin.right)
  .attr("height", height + margin.top + margin.bottom)
  .append("g")
  .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

// Инициализация пустых данных
var time = 0;
var t = 0;
var t_count = 0;
var max = 0;
var min = 0;
var max_x = 0;
var arr = [80, 10, 10];

var data = [210];



// Создание шкалы для оси y
var y = d3.scaleLinear().range([height, 0]);

// Создание оси x и y
var yAxis = d3.axisLeft(y);


// Функция для генерации случайных данных
function generateData(num) {
  // console.log(num)
  // t_count = 0;
  // t = ((220 - num) - arr[arr.length - 1]) / 20;
  // arr.push(num);
  // max = Math.max.apply(null, arr);
  // min = Math.min.apply(null, arr);
  // max_x = max - min;
  // t_count = 0;
  t = ((220 - num) - data[data.length - 1]) / 20;
  if (data.length > 100*50) {
    data.shift();
  }
}
//  console.log(Math.max.apply(null, data))
//  console.log(Math.min.apply(null, data))





// Функция для обновления графика с новыми данными
function update() {
  var num_2 = data[data.length - 1] + t
  data.push(num_2)
  // t_count++;
  // var arr2 = arr.slice();
  // var t1 = arr[arr.length - 2] + t * t_count;

  // arr2.pop();
  // var data = [200, 30];
  // arr2.forEach(i => {
  //   let x = i - min;
  //   let x_revers = 220 - x / max_x * 220;
  //   data.push(x_revers);
  // });
  // Добавляем новую точку данных
  // t_count++;
  // var t1 = (arr[arr.length - 2] + t * t_count)
  // console.log(arr);
  // data = [];

  // arr.slice(arr.length - 1);
  // arr.forEach(i => {
  //   // alert(i);
  //   var x = i - min;
  //   // alert(x + "2");
  //   // alert(max_x + "1")
  //   var x_revers = 220 - x / max_x * 220
  //   data.push(x_revers);
  // });

  // data.push(t1)
  console.log(data)
  // //  data.push(500)
  // Обновляем xScale++
  xScale.domain([0, data.length - 1]);

  // Обновляем линию
  svg.select("path")
    .attr("d", line(data))
    .attr("transform", null)
    .transition()
    .duration(0)
    .ease(d3.easeLinear)
    .attr("transform", "translate(" + xScale(0) + ",0)") // Сдвигаем влево на один пиксель

  y.domain([0, d3.max(data, function (d) { return Math.max.apply(null, data); })]);


  svg.selectAll("g.axis").remove();

  // Добавление осей
  svg.append("g")
    .attr("class", "axis")
    .attr("transform", "translate(0," + height + ")")

  svg.append("g")
    .attr("class", "axis")
    .call(yAxis);
}
var xScale = d3.scaleLinear()
  .domain([0, 100])
  .range([0, window.innerWidth]);

// Определяем line
var line = d3.line()
  .x(function (d, i) { return xScale(i); })
  .y(function (d) { return d; });



// Добавляем линию
svg.append("path")
  .datum(arr)
  .attr("fill", "none")
  .attr("stroke", "steelblue")
  .attr("stroke-width", 2);

// Запускаем обновление каждую секунду
// update();
// Инициализация графика с пустыми данными
setInterval(update, 50);


