$(".icon_password").click(function() {
  var t = $('.icon_password').css('background-image').split("/");
  if (t.pop().slice(0, -2) == "glass.png") {
    $('.icon_password').css({'background-image': "url(./glass_close.png)"})
    $('.password_input').attr("type", "password")
  } else {
    $('.icon_password').css({'background-image': "url(./glass.png)"})
    $('.password_input').attr("type", "text")
  }
});


$(".icon_password_confirm").click(function() {
  var t = $('.icon_password_confirm').css('background-image').split("/");
  if (t.pop().slice(0, -2) == "glass.png") {
    $('.icon_password_confirm').css({'background-image': "url(./glass_close.png)"})
    $('.password_confirm_input').attr("type", "password")
  } else {
    $('.icon_password_confirm').css({'background-image': "url(./glass.png)"})
    $('.password_confirm_input').attr("type", "text")
  }
});
