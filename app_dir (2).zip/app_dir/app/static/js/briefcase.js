$(document).ready(function () {
  let timer = 180/10;
  let turn = 0;

  function turnArrow() {
      let x = document.getElementById("arrow");
      turn += 10;
      x.style.transform = "rotate("+ (turn % 360) +"deg)"
    }

    $('.title_1 img').on('click', function () {
      $('.empty-content').slideToggle(600);
      $('.empty-content_line div').slideToggle(600);
      for (var i = 0;i < 180/10;i++) {
         setTimeout(turnArrow, timer * i)
      }
    });
});
